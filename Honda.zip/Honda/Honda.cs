﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Honda.Retailer;

namespace DhruvadeshHonda
{
    class Honda
    {
        static void Main(string[] args)
        {
            string inputStage = null;
            string engineType = null;
            string color = null;
            string variant = null;

            reEntryEngineType:
                Console.Write("Enter Engine Type: ");
                engineType = Console.ReadLine();
                Boolean checkEngineType = Retailer.ValidateEntry(engineType, "EngineType");
                if (!checkEngineType)
                {
                    inputStage = "reEntryEngineType";
                    goto reEntryExitOption;
                }

            reEntryBodyColor:
                Console.Write("Enter Color: ");
                color = Console.ReadLine();
                Boolean checkBodyColor = Retailer.ValidateEntry(color, "BodyColor");
                if (!checkBodyColor)
                {
                    inputStage = "reEntryBodyColor";
                    goto reEntryExitOption;
                }

            reEntryVariantType:
                Console.Write("Enter Variant: ");
                variant = Console.ReadLine();
                Boolean checkVariantType = Retailer.ValidateEntry(variant, "VariantType");
                if (!checkVariantType)
                {
                    inputStage = "reEntryVariantType";
                    goto reEntryExitOption;
                }

            
            reEntryExitOption:
                if (inputStage != null)
                {
                    Console.WriteLine("Do you want to Continue or Exit? (Continue/Exit)");
                    string userOption = Console.ReadLine();
                    switch (userOption)
                    {
                        case "Continue":
                        ok:
                            switch (inputStage)
                            {
                                case "reEntryEngineType":
                                    inputStage = null;
                                    goto reEntryEngineType;
                                case "reEntryBodyColor":
                                    inputStage = null;
                                    goto reEntryBodyColor;
                                case "reEntryVariantType":
                                    inputStage = null;
                                    goto reEntryVariantType;
                            }
                            break;
                        case "Exit":
                            Environment.Exit(1);
                            break;
                        default:
                            goto ok;

                    }
                }
                    
            Retailer.AccumulateEntry(engineType, color, variant);

            Console.Write("Do you want to add more cars? (Yes/No)");
            
            switch(Console.ReadLine())
            {
            
                case "Yes":
                yes:
                    goto reEntryEngineType;
                case "No":
                    Retailer.PlaceOrder();
                    break;
                default:
                    goto yes;
            }

        }
    }
}
