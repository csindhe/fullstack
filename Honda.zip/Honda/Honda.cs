﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Honda.Retailer;

namespace DhruvadeshHonda
{
    class Honda
    {
        static void Main(string[] args)
        {
            reEntry:
            Console.Write("Enter Engine Type: ");
            string engineType = Console.ReadLine();
            Console.Write("Enter Color: ");
            string color = Console.ReadLine();
            Console.Write("Enter Variant: ");
            string variant = Console.ReadLine();

            Retailer.AccumulateEntry(engineType, color, variant);

            Console.Write("Do you want to add more cars? (Yes/No)");
            
            switch(Console.ReadLine())
            {
            
                case "Yes":
                yes:
                    goto reEntry;
                case "No":
                    Retailer.PlaceOrder();
                    break;
                default:
                    goto yes;
            }

        }
    }
}
