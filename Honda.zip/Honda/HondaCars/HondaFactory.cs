﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Honda.HondaCars;

namespace HondaCars
{
    static class HondaFactory
    {
        static public void PlaceOrder(List<OrderItem> orders)
        {
            if(orders.Count > 0)
            {
                for(int i = 0; i < orders.Count; i++)
                {
                    Console.WriteLine(OrderNumberGenerator(orders[i].GetHashCode()));
                    Console.WriteLine($"{orders[i].Engine_Type}, {orders[i].Color}, {orders[i].Variant}");
                }
            }
        }

        static public DateTime ExpectedDeliveryDate(string orderId)
        {
            return new DateTime();
        }

        static private string OrderNumberGenerator(int currentHasCode)
        {
            Guid currentOrderId = Guid.NewGuid();
            return currentOrderId.ToString();
        }
    }
}


