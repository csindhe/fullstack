﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Honda.HondaCars
{
    struct OrderItem
    {
        public EngineType Engine_Type { get; }
        public BodyColor Color { get; }
        public VariantType Variant { get; }

        public OrderItem(EngineType engineType, BodyColor color, VariantType variant)
        {
            Engine_Type = engineType;
            Color = color;
            Variant = variant;
        }
    }

    enum EngineType
    {
        Diesel,
        Petrol,
        Electric,
        CNG
    }

    enum BodyColor
    {
        Grey,
        Black,
        White,
        Red
    }

    enum VariantType
    {
        VMT,
        VXMT,
        ZMT
    }
}
