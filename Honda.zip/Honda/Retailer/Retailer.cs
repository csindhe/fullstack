﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Honda.HondaCars;
using HondaCars;

namespace Honda.Retailer
{
    static class Retailer
    {
        static List<OrderItem> CarsForOrder = new List<OrderItem>();

        static public void PlaceOrder()
        {
            HondaFactory.PlaceOrder(CarsForOrder);
        }

        static public void AccumulateEntry(string engineType, string color, string variant)
        {
            try
            {
                CarsForOrder.Add(new OrderItem(
                    (EngineType)Enum.Parse(typeof(EngineType), engineType, true),
                    (BodyColor)Enum.Parse(typeof(BodyColor), color, true),
                    (VariantType)Enum.Parse(typeof(VariantType), variant, true)
                ));
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message + " Please check your input.");
            }
        }

    }
    
    
}
