﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Honda.HondaCars;
using HondaCars;

namespace Honda.Retailer
{
    static class Retailer
    {
        static List<OrderItem> CarsForOrder = new List<OrderItem>();

        static public void PlaceOrder()
        {
            HondaFactory.PlaceOrder(CarsForOrder);
        }

        static public void AccumulateEntry(string engineType, string color, string variant)
        {
            try
            {
                CarsForOrder.Add(new OrderItem(
                    (EngineType)Enum.Parse(typeof(EngineType), engineType, true),
                    (BodyColor)Enum.Parse(typeof(BodyColor), color, true),
                    (VariantType)Enum.Parse(typeof(VariantType), variant, true)
                ));
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message + " Please check your input.");
            }
        }

        static public Boolean ValidateEntry(string inputValue, string inputType)
        {
            try
            {
                Boolean isValid = CheckInputValidity(inputValue, inputType);
                if (!isValid)
                {
                    throw new ArgumentException($"Input Entered \"{inputValue}\" is not a valid \"{inputType}\". Please reenter.");
                }

                return isValid;
            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        static private Boolean CheckInputValidity(string inputValue, string inputType)
        {
            Boolean isValid = false;
            switch (inputType)
            {
                case "EngineType":
                    EngineType engineTypeVal;
                    if(EngineType.TryParse(inputValue, out engineTypeVal))
                    {
                        isValid = true;
                    }
                    break;
                case "BodyColor":
                    BodyColor bodyColorVal;
                    if (BodyColor.TryParse(inputValue, out bodyColorVal))
                    {
                        isValid = true;
                    }
                    break;
                case "VariantType":
                    VariantType variantTypeVal;
                    if (VariantType.TryParse(inputValue, out variantTypeVal))
                    {
                        isValid = true;
                    }
                    break;
            }

            return isValid;
        }

    }
    
    
}
